//package com.example.repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.example.entity.Blogs;
//
//public interface BlogsRepository extends JpaRepository<Blogs, Integer>{
//
//}
