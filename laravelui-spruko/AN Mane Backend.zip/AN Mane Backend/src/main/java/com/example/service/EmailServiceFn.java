package com.example.service;

public interface EmailServiceFn {

	 void sendThankYouEmail(String to, String subject, String text);
}
