//package com.example.repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.example.entity.WhyIBGInfotech;
//
//public interface WhyIBGInfotechRepository extends JpaRepository<WhyIBGInfotech, Integer>{
//
//}
