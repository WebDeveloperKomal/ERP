package com.example.util;

public class MailConstants {
	
	public static  String subject="Doucument uploaded for ";
	public static  String message="Dear Employee, Following Document uploaded for ";
	public static String frommailid="alert@ibgfincon.com";
	public static String OTP_MESSAGE="Dear Customer Please find your OTP ";
	public static String OTP_MESSAGE_SUBJECT="OTP Details";
	public static String MAIL_CUSTOMER_SUBJECT="A N Mane Account information";
	public  static String MAIL_CUSTOMER_INIT="Dear Sir/Madam,";
	public static String MAIL_CUSTOMER_DETAILS="A Very warm Welcome to A N Mane Family! You are just one step away from your Business Financial Planning. All you need to do is activate the IBGBiZ App by downloading from play store with your USER ID, and Password.  You may reset the password using OTP (Which will be sent to your registered mobile number) ";
	public static String MAIL_CUSTOMER_DETAILS1="For a step by step process please refer to the easy guides, or contact our Toll Free No 18002661294. Your account details as per your application are as follows.";
	public static String MAIL_CUSTOMER_DETAILS2="In case you find any discrepancies in the above mentioned details, we request you to inform us within 15 days from the receipt of this mail.\n"+
	"We also request you to carefully read the terms and Conditions document, Various Policies of the company. Which are available on our IBGBiZ App and website https://www.ibgfincon.com for your Information, This is for your benefit and Secure your Financial Information with IBG FINCON Pvt Ltd. Copies of your Client registration form (KYC) and other documents executed by you are accessible on the IBGBiZ App and website https://www.ibgfincon.com in the post Login Section.\n"+
	"Please Note that the Consent and authority letter which forms part of the Account Opening documents has been digitally accepted by IBG FINCON Pvt Ltd.\n"+
	"We look forward to establish a long-term relationship with you and assure you of our best services always.\n";
		
	public static String MAIL_CUSTOMER_DETAILS3="Best Regards,\n"+
	"Shrikant Dahihande\n"+
	"Head � Customer Service";
}
