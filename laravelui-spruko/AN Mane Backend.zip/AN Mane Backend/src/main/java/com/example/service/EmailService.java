package com.example.service;

import com.example.entity.SubscribeEmail;

public interface EmailService {
	
	 void sendThankYouEmail(String to, String subject, String text);

}
