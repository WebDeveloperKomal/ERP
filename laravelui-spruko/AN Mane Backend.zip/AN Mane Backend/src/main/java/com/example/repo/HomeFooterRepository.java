//package com.example.repo;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.example.entity.HomeFooter;
//
//public interface HomeFooterRepository extends JpaRepository<HomeFooter, Integer>{
//
//}
